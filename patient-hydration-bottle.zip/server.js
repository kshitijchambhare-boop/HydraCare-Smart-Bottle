// Optional local server (the site also works as static GitHub Pages).
// /api/sensor is the bridge where a real ESP32 can POST its readings later.
const express=require('express'),app=express();let last={};
app.use(express.json());app.use(express.static(__dirname));
app.get('/api/sensor',(q,r)=>r.json(last));
app.post('/api/sensor',(q,r)=>{const{event,ml,weight,temp}=q.body||{};if(!event)return r.status(400).json({error:'event required'});last={event,ml,weight,temp,t:Date.now()};r.json(last)});
app.listen(3000,()=>console.log('Open http://localhost:3000'));
